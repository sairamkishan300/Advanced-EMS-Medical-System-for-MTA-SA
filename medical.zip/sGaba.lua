local areaCirurgia = createColRectangle (1250.67615, -1759.88379, 14.65550, 35, 35 )
local radarCirurgia = createRadarArea (1231.03320, -1779.7711, 35, 35, 0, 255, 0, 175 )

local entrouSaiu = false

function entrouRadar( thePlayer, matchingDimension )
	if (getElementType(thePlayer) == "player") then
        entrouSaiu = true
    end
end
addEventHandler( "onColShapeHit", areaCirurgia, entrouRadar )

function saiuRadar ( thePlayer, matchingDimension )
   if (getElementType(thePlayer) == "player") then
		entrouSaiu = false
   end
end
addEventHandler ( "onColShapeLeave", areaCirurgia, saiuRadar )

addEventHandler("onResourceStart", resourceRoot, 
    function() 
        for i,v in ipairs(getElementsByType('player')) do 
            setElementData(v, "data.playerID", i) 
        end 
    end 
) 

addEventHandler("onPlayerJoin", root, 
    function() 
        for i,v in ipairs(getElementsByType('player')) do 
            setElementData(v, "data.playerID", i) 
        end 
    end 
) 

local blip = {}

-- Track last damage info per player for cause-of-death classification
local lastDamageInfo = {}

-- EMS call queue (death menu / EMS panel)
local emsCalls = {}
local nextEMSCallId = 1

local emsCallsByAccount = {} -- key: account/identifier, value: { callId, count }

local emsCallBlips = {}   -- keyed by callId
local emsCallMarkers = {} -- keyed by callId

local function broadcastEMSAddCall(callId, patientName)
    for _, player in ipairs(getElementsByType("player")) do
        if isPlayerInEmsDuty(player) then
            triggerClientEvent(player, "emsAddCall", player, tostring(callId), patientName)
        end
    end
end

local function clearEMSCall(callId)
	callId = tonumber(callId)
	if not callId then return end
	local data = emsCalls[callId]
	if not data then return end

	if data.accountName and emsCallsByAccount[data.accountName] and emsCallsByAccount[data.accountName].callId == callId then
		emsCallsByAccount[data.accountName] = nil
	end

	if emsCallBlips[callId] and isElement(emsCallBlips[callId]) then
		destroyElement(emsCallBlips[callId])
		emsCallBlips[callId] = nil
	end
	if emsCallMarkers[callId] and isElement(emsCallMarkers[callId]) then
		destroyElement(emsCallMarkers[callId])
		emsCallMarkers[callId] = nil
	end

	emsCalls[callId] = nil
	broadcastEMSRemoveCall(callId)
end

local function broadcastEMSRemoveCall(callId)
    for _, player in ipairs(getElementsByType("player")) do
        if isPlayerInEmsDuty(player) then
            triggerClientEvent(player, "emsRemoveCall", player, tostring(callId))
        end
    end
end

local function findCallIdByPatient(patient)
    for id, data in pairs(emsCalls) do
        if data.patient == patient then
            return id
        end
    end
end

function outputDxBox(thePlayer, text, type)
	exports.BCR_MensagemDX:outputDx(thePlayer, text, type)
end

function getPlayerFromPartialName(name)
    local name = name and name:gsub("#%x%x%x%x%x%x", ""):lower() or nil
    if name then
        for _, player in ipairs(getElementsByType("player")) do
            local name_ = getPlayerName(player):gsub("#%x%x%x%x%x%x", ""):lower()
            if name_:find(name, 1, true) then
                return player
            end
        end
    end
end	

local function getAccountOrPlayerName(player)
	local acc = getPlayerAccount(player)
	if acc and not isGuestAccount(acc) then
		return getAccountName(acc)
	end
	return getPlayerName(player)
end

local function hasEMSAccess(player)
	if not isElement(player) or getElementType(player) ~= "player" then return false end
	local acc = getPlayerAccount(player)
	if not acc or isGuestAccount(acc) then return false end
	local groupName = _G.EMS_ACL_GROUP or "EmsDuty"
	local group = aclGetGroup(groupName)
	if not group then return false end
	return isObjectInACLGroup("user." .. getAccountName(acc), group)
end

-- Configuration variable for immunity period (in milliseconds)
local KNOCK_IMMUNITY_PERIOD = 60000 -- 60 seconds

function setPlayerFallen(player, state)
	if state == true then
		-- Do not touch controls here; just mark fallen and let client/UI handle behavior
		setElementHealth(player, 100) -- Set health to 100 only once when knocked
		setElementData(player, "playerFallen", true)
		-- Classify cause of death based on last recorded damage
		local cause = "Unknown"
		local info = lastDamageInfo[player]
		if info then
			local weapon = info.weapon or 0
			if info.environment == "drown" then
				cause = "Drowning"
			elseif info.environment == "fire" then
				cause = "Burnt"
			elseif info.environment == "fall" then
				cause = "Fall Impact"
			elseif weapon >= 22 and weapon <= 34 then
				cause = "Bullet Wound"
			elseif weapon == 51 or weapon == 16 or weapon == 17 or weapon == 18 or weapon == 39 then
				cause = "Explosion"
			elseif weapon == 37 or weapon == 38 or weapon == 42 then
				cause = "Burnt"
			elseif weapon >= 2 and weapon <= 15 then
				cause = "Melee Trauma"
			end
		end
		setElementData(player, "ems.causeOfDeath", cause)
		setElementData(player, "knockImmunityEnd", getTickCount() + KNOCK_IMMUNITY_PERIOD)
		setElementFrozen(player, true)
		triggerClientEvent(player, "startDeadTime", player)
		triggerClientEvent(player, "showKnockMenu", player)
		triggerClientEvent(player, "startKnockImmunityTimer", player, KNOCK_IMMUNITY_PERIOD)
		setAccountData(getPlayerAccount(player), "isPlayerKnockOut", true)
	elseif state == false then
		if isElement(player) then
			setElementHealth(player, 40) -- Set health to 40% when revived
			triggerClientEvent(player, "stopDeadTime", player)
			triggerClientEvent(player, "stopKnockImmunityTimer", player)
			setElementData(player, "playerFallen", false)
			setElementData(player, "knockImmunityEnd", nil)
			setElementFrozen(player, false)
			triggerClientEvent(player, "hideKnockMenu", player)
			setAccountData(getPlayerAccount(player), "isPlayerKnockOut", false)
		end
	end
end

-- Function to check if a player is in EmsDuty ACL group
function isPlayerInEmsDuty(player)
	return hasEMSAccess(player)
end

-- Function to notify all EMS players
function notifyEMSPlayers(message, type)
    for _, player in ipairs(getElementsByType("player")) do
        if isPlayerInEmsDuty(player) then
            triggerClientEvent(player, "add:notification", player, message, type, true)
		end
	end
end

function checkHealth()
	for i, player in pairs (getElementsByType("player")) do
		if not getElementData(player, "playerFallen") then
			local conta = getAccountName(getPlayerAccount(player))
				if getElementHealth(player) >= 1 then
					if getElementHealth(player) <= hpFallen then 
						removePedFromVehicle(player)
						setPlayerFallen(player, true)
						setPedAnimation(player, "SWEET", "Sweet_injuredloop", 1000, false, false, false, true)
						triggerClientEvent(player, "startDeadTime", player)
						triggerClientEvent(player, "add:notification", player, "You are knocked out! Wait for someone to revive you or wait for immunity to end.", "warn", true)
							setTimer(function()
								if getElementData(player, "playerFallen") then	
									setElementData(player, "playerFallen", false)
									setPlayerFallen(player, false)
									triggerClientEvent(player, "stopDeadTime", player)
								if isElement(blip[player]) then
									    destroyElement(blip[player])
									end
									killPed(player)
								triggerClientEvent(player, "add:notification", player, "You took too long to get help and died!", "error", true)
								end
							end, 900000, 1)
					end
				end
		else
			-- Check if knocked player's health reaches 0
			if getElementHealth(player) <= 0 then
				setElementData(player, "playerFallen", false)
				setPlayerFallen(player, false)
				triggerClientEvent(player, "stopDeadTime", player)
				if isElement(blip[player]) then
					destroyElement(blip[player])
				end
				killPed(player)
				triggerClientEvent(player, "add:notification", player, "You died from your injuries!", "error", true)
				end
			end
		end
end
setTimer(checkHealth, 1000, 0)

function helpCommand(source)
	for i, player in pairs (getElementsByType("player")) do
	--	if getElementData(source, "playerFallen") then
			if hasEMSAccess(player) then
			    triggerClientEvent(player, "add:notification", player, "[EMS] The player "..getPlayerName(source).." is asking for help! Look for the heart blip.", "info", true)
			    outputDxBox(source, "You called the emergency number! Hold.", "info")
			    if blip[source] and isElement(blip[source]) then 
			    	destroyElement(blip[source]) 
			    	blip[source] = nil 
			    end
			    local x, y, z = getElementPosition(source)
			    blip[source] = createBlip(x, y, z, 21)
				--setElementVisibleTo(blip[source], root, false)
				--setElementVisibleTo(blip[source], player, true)
			end
	  --  else
			outputDxBox(source, "you don't need service.", "error")
	--	end
	end
end
addCommandHandler("192", helpCommand)

function onWasted(killer)
        if getElementData(source, "playerFallen") then
            setPlayerFallen(source, false)
            setElementData(source, "playerFallen", false)
            triggerClientEvent(source, "stopDeadTime", source)
            triggerClientEvent(source, "hideKnockMenu", source)
            triggerClientEvent(source, "showDeathMenu", source)
            if blip[source] and isElement(blip[source]) then 
                destroyElement(blip[source]) 
                blip[source] = nil 
            end
        
        -- Clear inventory and money when player dies after being knocked
        exports.inventory:clearInventory(source)
        setPlayerMoney(source, 0)
        -- Also clear any EMS call this player was involved in
        for callId, data in pairs(emsCalls) do
            if data.patient == source or data.ems == source then
                clearEMSCall(callId)
            end
        end
    end
end
addEventHandler("onPlayerWasted", root, onWasted)

function onQuit()
	for i, player in pairs (getElementsByType("player")) do
		if getElementData(player, "playerFallen") then
			if blip[player] and isElement(blip[player]) then 
				destroyElement(blip[player]) 
				blip[player] = nil 
			end
		end
	end

	-- Clear any EMS calls where this player was patient or EMS
	for callId, data in pairs(emsCalls) do
		if data.patient == source or data.ems == source then
			clearEMSCall(callId)
		end
	end
end
addEventHandler("onPlayerQuit", root, onQuit)

--------------------------------------------------------------------------------------------------

function message(player, message, type)
	triggerClientEvent(player, "add:notification", player, message, type, true)
    --triggerClientEvent(player, "N3xT.dxNotification", resourceRoot, message, type)
end

-- Optional: send EMS events to a dedicated Discord webhook
local function sendEMSMedicalWebhook(content)
	if not EMS_DISCORD_WEBHOOK or EMS_DISCORD_WEBHOOK == "" then return end

	local time = getRealTime()
	local timestamp = string.format("[%02d-%02d-%04d %02d:%02d:%02d]",
		time.monthday, time.month + 1, time.year + 1900,
		time.hour, time.minute, time.second
	)

	local finalMessage = timestamp .. " " .. content

	-- Send to Discord as a code block
	local sendOptions = {
		formFields = {
			content = "```" .. finalMessage .. "```"
		},
	}
	fetchRemote(EMS_DISCORD_WEBHOOK, sendOptions, function() end)

	-- Also log to local file logs/emsLogs.txt
	local logFile = fileOpen("logs/emsLogs.txt") or fileCreate("logs/emsLogs.txt")
	if not logFile then
		outputDebugString("[EMS] Failed to open or create emsLogs.txt", 1)
		return
	end

	fileSetPos(logFile, fileGetSize(logFile))
	fileWrite(logFile, finalMessage .. "\n")
	fileFlush(logFile)
	fileClose(logFile)
end

-- Handle EMS call from death menu (queue it for EMS panel)
addEvent("onDeathMenuCallEMS", true)
addEventHandler("onDeathMenuCallEMS", root, function()
	if source and isElement(source) then
		local patientName = getAccountOrPlayerName(source)

		-- If this account already has a call, just bump its count/priority
		local existing = emsCallsByAccount[patientName]
		if existing and emsCalls[existing.callId] then
			existing.count = existing.count + 1
			emsCalls[existing.callId].count = existing.count

			-- Inform EMS panels to update display count
			for _, player in ipairs(getElementsByType("player")) do
				if isPlayerInEmsDuty(player) then
					triggerClientEvent(player, "emsUpdateCallCount", player, tostring(existing.callId), existing.count)
				end
			end
			-- still notify patient that EMS were notified
			triggerClientEvent(source, "add:notification", source, "Emergency services have been notified of your location!", "info", true)
			return
		end

		local callId = nextEMSCallId
		nextEMSCallId = nextEMSCallId + 1

		emsCalls[callId] = {
			patient = source,
			ems = nil,
			accountName = patientName,
			count = 1
		}

		emsCallsByAccount[patientName] = { callId = callId, count = 1 }

		-- Notify the patient
		triggerClientEvent(source, "add:notification", source, "Emergency services have been notified of your location!", "info", true)

		-- Notify all EMS players and push into their panel list
		notifyEMSPlayers(patientName .. " needs medical assistance! Check your EMS panel.", "info")
		broadcastEMSAddCall(callId, patientName)
	end
end)

-- EMS picks a call from the panel
addEvent("onEMSCallPicked", true)
addEventHandler("onEMSCallPicked", root, function(callId)
	local emsPlayer = client
	if not emsPlayer or not isElement(emsPlayer) then return end
	if not isPlayerInEmsDuty(emsPlayer) then return end

	callId = tonumber(callId)
	if not callId then return end

	local data = emsCalls[callId]
	if not data or not isElement(data.patient) then
		-- Call no longer valid, remove from panels
		emsCalls[callId] = nil
		broadcastEMSRemoveCall(callId)
		return
	end

	-- If already taken by another EMS, ignore
	if data.ems and data.ems ~= emsPlayer then
		return
	end

	data.ems = emsPlayer

	local px, py, pz = getElementPosition(data.patient)

	-- Create blip and marker visible only to this EMS
	if emsCallBlips[callId] and isElement(emsCallBlips[callId]) then
		destroyElement(emsCallBlips[callId])
		emsCallBlips[callId] = nil
	end
	if emsCallMarkers[callId] and isElement(emsCallMarkers[callId]) then
		destroyElement(emsCallMarkers[callId])
		emsCallMarkers[callId] = nil
	end

	local bl = createBlip(px, py, pz, 21)
	setBlipVisibleDistance(bl, 250)
	setElementVisibleTo(bl, root, false)
	setElementVisibleTo(bl, emsPlayer, true)

	local mk = createMarker(px, py, pz - 1, "checkpoint", 4, 255, 0, 0, 150)
	setElementVisibleTo(mk, root, false)
	setElementVisibleTo(mk, emsPlayer, true)

	emsCallBlips[callId] = bl
	emsCallMarkers[callId] = mk

	setElementData(mk, "emsCallId", callId)
	setElementData(mk, "emsCallEMS", emsPlayer)

	-- Inform EMS and patient (use account name where possible)
	local patientName = getAccountOrPlayerName(data.patient)
	local emsName = getAccountOrPlayerName(emsPlayer)
	triggerClientEvent(emsPlayer, "add:notification", emsPlayer, "You picked the call from " .. patientName .. ". A marker has been set.", "success", true)
	triggerClientEvent(data.patient, "add:notification", data.patient, "An EMS has picked your call. Stay where you are!", "success", true)

	-- Send system message into EMS chat panel for all EMS
	local sysMessage = string.format("Doctor %s picked a call from %s", emsName, patientName)
	for _, player in ipairs(getElementsByType("player")) do
		if isPlayerInEmsDuty(player) then
			triggerClientEvent(player, "onEMSChatMessageReceived", player, "SYSTEM", sysMessage)
		end
	end

	sendEMSMedicalWebhook(sysMessage)

	-- Remove from all panels (assigned now)
	broadcastEMSRemoveCall(callId)
end)

addEventHandler("onMarkerHit", root, function(element, matchingDimension)
	if getElementType(element) ~= "player" or not matchingDimension then return end
	local callId = getElementData(source, "emsCallId")
	local emsPlayer = getElementData(source, "emsCallEMS")
	if not callId or not emsPlayer or element ~= emsPlayer then return end

	callId = tonumber(callId)
	local data = emsCalls[callId]
	if not data then return end

	-- Reached the marker: clear blip/marker and call data
	if emsCallBlips[callId] and isElement(emsCallBlips[callId]) then
		destroyElement(emsCallBlips[callId])
		emsCallBlips[callId] = nil
	end
	if emsCallMarkers[callId] and isElement(emsCallMarkers[callId]) then
		destroyElement(emsCallMarkers[callId])
		emsCallMarkers[callId] = nil
	end

	emsCalls[callId] = nil

	local patientName = getAccountOrPlayerName(data.patient)
	triggerClientEvent(emsPlayer, "add:notification", emsPlayer, "You reached the patient " .. patientName .. ".", "info", true)
	if isElement(data.patient) then
		triggerClientEvent(data.patient, "add:notification", data.patient, "EMS has arrived at your location.", "info", true)
	end
end)

-- Handle player death after knockout
addEvent("onPlayerDeathAfterKnockout", true)
addEventHandler("onPlayerDeathAfterKnockout", root, function()
    if source and isElement(source) then
        exports.inventory:clearInventory(source)
        setPlayerMoney(source, 0)
    end
end)

-- Remove blip when player quits
addEventHandler("onPlayerQuit", root, function()
    if blip[source] and isElement(blip[source]) then 
        destroyElement(blip[source]) 
        blip[source] = nil 
    end
end)

-- Damage immunity system
function preventDamageForKnockedPlayers(attacker, weapon, bodypart, loss)
	if getElementData(source, "playerFallen") then
        local immunityEnd = getElementData(source, "knockImmunityEnd")
        if immunityEnd and getTickCount() < immunityEnd then
            -- Player is still in immunity period, prevent damage
        cancelEvent()
        setElementHealth(source, 100)
        -- Record cause-of-death
        local env = nil
        if isElementInWater(source) then
            env = "drown"
        elseif weapon == 37 or weapon == 38 or weapon == 42 then
            env = "fire"
        elseif weapon == 54 then
            env = "fall"
        end
        lastDamageInfo[source] = { attacker = attacker, weapon = weapon, bodypart = bodypart, loss = loss, environment = env }
        end
        -- Otherwise, damage will go through normally
    end
end
addEventHandler("onPlayerDamage", root, preventDamageForKnockedPlayers)

-- Record last damage info for cause-of-death
addEventHandler("onPlayerDamage", root, function(attacker, weapon, bodypart, loss)
	local env = nil
	if isElementInWater(source) then
		env = "drown"
	elseif weapon == 37 or weapon == 38 or weapon == 42 then
		env = "fire"
	elseif weapon == 54 then
		env = "fall"
	end
	lastDamageInfo[source] = { attacker = attacker, weapon = weapon, bodypart = bodypart, loss = loss, environment = env }
end)

-- EMS revive/heal flow
addEvent("emsRequestRevivePanel", true)
addEventHandler("emsRequestRevivePanel", root, function(target)
	local ems = client
	if not ems or not isElement(ems) or not isElement(target) or getElementType(target) ~= "player" then return end
	if not hasEMSAccess(ems) then return end
	local ex, ey, ez = getElementPosition(ems)
	local tx, ty, tz = getElementPosition(target)
	if getDistanceBetweenPoints3D(ex, ey, ez, tx, ty, tz) > 4 then return end
	local fallen = getElementData(target, "playerFallen") and true or false
	local hp = getElementHealth(target) or 0
	local cause = getElementData(target, "ems.causeOfDeath") or "Unknown"
	local acc = getPlayerAccount(target)
	local accName = (acc and not isGuestAccount(acc)) and getAccountName(acc) or "Guest"
	triggerClientEvent(ems, "emsOpenRevivePanel", ems, target, accName, hp, fallen, cause, accName)
end)

addEvent("emsPerformRevive", true)
addEventHandler("emsPerformRevive", root, function(target)
	local ems = client
	if not ems or not isElement(ems) or not isElement(target) or getElementType(target) ~= "player" then return end
	if not hasEMSAccess(ems) then return end
	local ex, ey, ez = getElementPosition(ems)
	local tx, ty, tz = getElementPosition(target)
	if getDistanceBetweenPoints3D(ex, ey, ez, tx, ty, tz) > 4 then return end
	if not getElementData(target, "playerFallen") then return end
	-- Use the shared knock handler to restore controls, health, menus, etc.
	setPlayerFallen(target, false)
	-- Extra safety: clear any remaining animation, camera, and blip
	setPedAnimation(target, false)
	setCameraTarget(target, target)
	if blip[target] and isElement(blip[target]) then
		destroyElement(blip[target])
		blip[target] = nil
	end
	setElementData(target, "playerFallen", false)
	setElementData(target, "knockImmunityEnd", nil)
	triggerClientEvent(target, "hideKnockMenu", target)
	triggerClientEvent(ems, "add:notification", ems, "You successfully revived " .. getPlayerName(target) .. ".", "success", true)
	triggerClientEvent(target, "add:notification", target, "You have been revived by EMS.", "success", true)
end)

addEvent("emsPerformHeal", true)
addEventHandler("emsPerformHeal", root, function(target)
	local ems = client
	if not ems or not isElement(ems) or not isElement(target) or getElementType(target) ~= "player" then return end
	if not hasEMSAccess(ems) then return end
	local ex, ey, ez = getElementPosition(ems)
	local tx, ty, tz = getElementPosition(target)
	if getDistanceBetweenPoints3D(ex, ey, ez, tx, ty, tz) > 4 then return end
	if getElementData(target, "playerFallen") then return end
	local hp = getElementHealth(target) or 0
	if hp >= 100 then return end
	setElementHealth(target, 100)
	triggerClientEvent(ems, "add:notification", ems, "You treated and healed " .. getPlayerName(target) .. ".", "success", true)
	triggerClientEvent(target, "add:notification", target, "You have been treated by EMS.", "success", true)
end)