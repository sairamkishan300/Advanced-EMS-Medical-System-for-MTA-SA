local function hasEMSAccess(player)
	if not isElement(player) or getElementType(player) ~= "player" then return false end
	local acc = getPlayerAccount(player)
	if not acc or isGuestAccount(acc) then return false end
	local groupName = _G.EMS_ACL_GROUP or "EmsDuty"
	local group = aclGetGroup(groupName)
	if not group then return false end
	return isObjectInACLGroup("user." .. getAccountName(acc), group)
end

-- Handle account name requests
addEvent("requestAccountName", true)
addEventHandler("requestAccountName", root, function()
	if client and isElement(client) then
        local accountName = getAccountName(getPlayerAccount(client))
        triggerClientEvent(client, "onReceiveAccountName", client, accountName)
    end
end)

addEvent("onEMSChatMessageReceived", true)
addEventHandler("onEMSChatMessageReceived", root, function(message)
	if client and isElement(client) and message then
		-- Check if the player is in EMS ACL group via shared config.acl
		if hasEMSAccess(client) then
			local acc = getPlayerAccount(client)
			if acc and not isGuestAccount(acc) then
				local accountName = getAccountName(acc)
				-- Broadcast the message to all EMS members
				for _, player in ipairs(getElementsByType("player")) do
					if hasEMSAccess(player) and player ~= client then
						triggerClientEvent(player, "onEMSChatMessageReceived", player, accountName, message)
					end
				end
			end
		end
	end
end)