addCommandHandler("ids",
function(player, command)
	players = getElementsByType("player")
	for id,p in ipairs(players) do
		outputChatBox(getPlayerName(p) .. ": " .. tostring(id), player)
	end
end)

function getIDFromPlayer(player)
	if player then
		local theid
		players = getElementsByType("player")
		for id,p in ipairs(players) do
			if player == p then
				theid = i
			end
		end
		return theid
	else return false end
end

function getPlayerFromID(theID)
	if theID then
		theID = tonumber(theID)
		local theplayer
		players = getElementsByType("player")
		for id,p in ipairs(players) do
			if theID == id then
				theplayer = p
			end
		end
		return theplayer
	else return false end
end

