local browser = nil
local showing = false
local screenW, screenH = guiGetScreenSize()
local panelW, panelH = 1000, 600  -- Panel dimensions
local panelX = (screenW - panelW) / 2  -- Center horizontally
local panelY = (screenH - panelH) / 2  -- Center vertically
local myAccountName = nil -- Store account name received from server

local function addBrowserEMSCall(callId, patientName)
    if browser then
        local safeId = tostring(callId):gsub("'", "\\'")
        local safeName = tostring(patientName or "Unknown"):gsub("'", "\\'")
        local jsCall = string.format("addEMSCall('%s', '%s');", safeId, safeName)
        executeBrowserJavascript(browser, jsCall)
    end
end

local function updateBrowserEMSCallCount(callId, count)
    if browser then
        local safeId = tostring(callId):gsub("'", "\\'")
        local jsCall = string.format("updateEMSCallCount('%s', %d);", safeId, tonumber(count) or 1)
        executeBrowserJavascript(browser, jsCall)
    end
end

local function removeBrowserEMSCall(callId)
    if browser then
        local safeId = tostring(callId):gsub("'", "\\'")
        local jsCall = string.format("removeEMSCall('%s');", safeId)
        executeBrowserJavascript(browser, jsCall)
    end
end

-- EMS calls list sync from server -> browser
addEvent("emsAddCall", true)
addEventHandler("emsAddCall", root, function(callId, patientName)
    if callId and patientName then
        addBrowserEMSCall(callId, patientName)
    end
end)

addEvent("emsRemoveCall", true)
addEventHandler("emsRemoveCall", root, function(callId)
    if callId then
        removeBrowserEMSCall(callId)
    end
end)

addEvent("emsUpdateCallCount", true)
addEventHandler("emsUpdateCallCount", root, function(callId, count)
    if callId and count then
        updateBrowserEMSCallCount(callId, count)
    end
end)

function createPanel()
    if not browser then
        browser = createBrowser(panelW, panelH, true, true)
        
        addEventHandler("onClientBrowserCreated", browser, function()
            loadBrowserURL(browser, "http://mta/local/medicalpanel.html")
        end)
        
        addEventHandler("onClientBrowserDocumentReady", browser, function()
            executeBrowserJavascript(browser, "document.body.style.display = 'block';")
        end)
        
        -- Enable browser input when clicking
        addEventHandler("onClientClick", root, function(button, state, absoluteX, absoluteY)
            if showing and button == "left" and state == "down" then
                if isCursorInPanel(absoluteX, absoluteY) then
                    injectBrowserMouseDown(browser, button)
                    focusBrowser(browser)
                end
            end
        end)
        
        showCursor(false)
        guiSetInputMode("allow_binds")
    end
end

function isCursorInPanel(x, y)
    return (x >= panelX and x <= panelX + panelW and
            y >= panelY and y <= panelY + panelH)
end

function togglePanel()
    if not browser then
        createPanel()
        return
    end
    
    showing = not showing
    if showing then
        showCursor(true)
        guiSetInputMode("no_binds")
        setBrowserRenderingPaused(browser, false)
        executeBrowserJavascript(browser, "document.body.style.display = 'block';")
        focusBrowser(browser)
    else
        showCursor(false)
        guiSetInputMode("allow_binds")
        executeBrowserJavascript(browser, "document.body.style.display = 'none';")
        setBrowserRenderingPaused(browser, true)
    end
end

-- Chat functionality
function addChatMessage(name, message, isOutgoing)
    if browser then
        local jsCall = string.format("addChatMessage('%s', '%s', %s);", 
            name:gsub("'", "\\'"), 
            message:gsub("'", "\\'"), 
            tostring(isOutgoing))
        executeBrowserJavascript(browser, jsCall)
    end
end

addEvent("onEMSChatMessage", true)
addEventHandler("onEMSChatMessage", root, function(message)
    if message then
        -- Send the message to the server
        triggerServerEvent("onEMSChatMessageReceived", localPlayer, message)
        -- Add the message to our chat (as outgoing)
        if myAccountName then
            addChatMessage(myAccountName, message, true)
        end
    end
end)

-- Receive account name from server
addEvent("onReceiveAccountName", true)
addEventHandler("onReceiveAccountName", root, function(accountName)
    myAccountName = accountName
end)

-- Receive chat messages from other EMS members
addEvent("onEMSChatMessageReceived", true)
addEventHandler("onEMSChatMessageReceived", root, function(playerName, message)
    addChatMessage(playerName, message, false)
end)

-- Called from browser JS when an EMS clicks "Pick Call" on a patient
addEvent("onPickEMSCall", true)
addEventHandler("onPickEMSCall", root, function(callId)
    if callId then
        triggerServerEvent("onEMSCallPicked", localPlayer, tostring(callId))
    end
end)

-- Mouse movement handling
addEventHandler("onClientCursorMove", root, function(_, _, absoluteX, absoluteY)
    if showing and browser and isCursorInPanel(absoluteX, absoluteY) then
        local relativeX = absoluteX - panelX
        local relativeY = absoluteY - panelY
        injectBrowserMouseMove(browser, relativeX, relativeY)
    end
end)

-- Mouse click handling
addEventHandler("onClientClick", root, function(button, state, absoluteX, absoluteY)
    if showing and browser and isCursorInPanel(absoluteX, absoluteY) then
        if state == "down" then
            injectBrowserMouseDown(browser, button)
        else
            injectBrowserMouseUp(browser, button)
        end
    end
end)

-- Mouse wheel handling
addEventHandler("onClientKey", root, function(button, press)
    if showing and browser and (button == "mouse_wheel_up" or button == "mouse_wheel_down") then
        local cursorX, cursorY = getCursorPosition()
        if cursorX and cursorY then
            local absoluteX, absoluteY = cursorX * screenW, cursorY * screenH
            if isCursorInPanel(absoluteX, absoluteY) then
                local value = (button == "mouse_wheel_down" and -1 or 1) * 40
                injectBrowserMouseWheel(browser, value)
            end
        end
    end
end)

addEventHandler("onClientResourceStart", resourceRoot,
    function()
        createPanel()
        bindKey("F4", "down", "toggleMedicalPanel")
        -- Request account name from server
        triggerServerEvent("requestAccountName", localPlayer)
    end
)

addEvent("onMedicalPanelClose", true)
addEventHandler("onMedicalPanelClose", root,
    function()
        if showing then
            togglePanel()
        end
    end
)

function handlePanelCommand(cmd)
    triggerServerEvent("checkMedicalACL", localPlayer)
end
addCommandHandler("toggleMedicalPanel", handlePanelCommand)

addEvent("allowMedicalPanel", true)
addEventHandler("allowMedicalPanel", root,
    function(allowed)
        if allowed then
            togglePanel()
        else
            outputChatBox("You don't have permission to use the medical panel.", 255, 0, 0)
        end
    end
)

-- Draw the browser on the screen
addEventHandler("onClientRender", root, function()
    if showing and browser then
        dxDrawImage(panelX, panelY, panelW, panelH, browser, 0, 0, 0, tocolor(255, 255, 255, 255), true)
    end
end) 