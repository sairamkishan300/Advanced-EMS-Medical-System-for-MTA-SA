local function hasEMSAccess(player)
	if not isElement(player) or getElementType(player) ~= "player" then return false end
	local acc = getPlayerAccount(player)
	if not acc or isGuestAccount(acc) then return false end
	local groupName = _G.EMS_ACL_GROUP or "EmsDuty"
	local group = aclGetGroup(groupName)
	if not group then return false end
	return isObjectInACLGroup("user." .. getAccountName(acc), group)
end

addEvent("checkMedicalACL", true)
addEventHandler("checkMedicalACL", root,
    function()
        if client and isElement(client) then
			local hasAccess = hasEMSAccess(client)
			triggerClientEvent(client, "allowMedicalPanel", client, hasAccess)
        end
    end
)