EMS_ACL_GROUP = "EmsDuty"

-- Optional: Discord webhook URL for EMS medical logs (calls, revives, etc.)
-- Leave as empty string to disable Discord logging from this resource.
EMS_DISCORD_WEBHOOK = "https://discord.com/api/webhooks/1340305491619877006/XdWmpkg8L"
