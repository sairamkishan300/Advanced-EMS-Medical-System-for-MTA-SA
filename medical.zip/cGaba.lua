--[[


 ################################################
 #                                              #                                                  
 #             SCRIPT PRODUZIDO POR:            #
 #             DISCORD.GG\Gaba#1017             #
 #                                              #
 #                                              #
 ################################################




]]

local x,y,z,rx,ry,rz= 0,-1.5,-0.1,0,0,-90


local screenW, screenH = guiGetScreenSize()
local resW, resH = 1360,768
local x, y = (screenW/resW), (screenH/resH)
local screenWidth, screenHeight = guiGetScreenSize()
local myScreenSource = dxCreateScreenSource(screenWidth, screenHeight)
local flickerStrength = 0
local dxfont0_fonte = dxCreateFont("font/fonte.ttf", 13)

local isKnockMenuActive = false
local deathMenuVisible = false
local deathMenuBrowser = nil

local immunityEndTime = 0
local showImmunityTimer = false

-- EMS revive/heal panel browser
local reviveBrowser = nil
local revivePanelVisible = false
local currentReviveTarget = nil
local reviveDocReady = false
local pendingReviveData = nil

function showKnockMenu()
    showCursor(true)
    isKnockMenuActive = true
    -- Show the death menu
    showDeathMenu()
end

function hideKnockMenu()
    showCursor(false)
    isKnockMenuActive = false
    -- Hide the death menu
    hideDeathMenu()
end

addEvent("showKnockMenu", true)
addEventHandler("showKnockMenu", root, showKnockMenu)
addEvent("hideKnockMenu", true)
addEventHandler("hideKnockMenu", root, hideKnockMenu)


function blockDead()
    if getElementHealth(localPlayer) <= 1 then
        if not getElementData(localPlayer, "jobSAMU") then
            if not getElementData(localPlayer, "playerFallen") then
                cancelEvent()
            end
        end
    end
end
addEventHandler("onClientPlayerDamage", localPlayer, blockDead)


function text()
    for _, player in ipairs(getElementsByType('player')) do
        if isElementOnScreen(player) and getElementData(player, "playerFallen") then
            local x, y, z = getElementPosition(player)
            local cx, cy, cz = getCameraMatrix()
            local vx, vy, vz = getPedBonePosition(player, 8)
            local dist = getDistanceBetweenPoints3D(cx, cy, cz, vx, vy, vz)
            local drawDistance = 30.0
            if (dist < drawDistance or player == target) then
                if(isLineOfSightClear(cx, cy, cz, vx, vy, vz, true, false, false)) then
                    local x, y = getScreenFromWorldPosition (vx, vy, vz + 0.6)
                    if(x and y) then
                        local px, py = getScreenFromWorldPosition (vx, vy, vz + 0.3)
                        local w = dxGetTextWidth("NEEDING A CURE!", 1, "default-bold")
                        local h = dxGetFontHeight(1, "default-bold")
                        dxDrawImage(x -6  - w / 2,y - 15 - h - 12, w + 25, h + 115, 'images/hp.png', 0, 0, 0, tocolor(255, 0, 0, math.abs(math.sin(getTickCount()/170))*200))
                        --dxDrawRectangle(x -6  - w / 2,y - 15 - h - 12, w + 9, h, tocolor(0, 0, 0, 194), false)
                        --dxDrawText("#FFFFFFPRECISANDO DE #FF0000CURA#FFFFFF!", x - 0  - w / 2,y - 15 - h - 12, w, h, tocolor(255,0,0, math.abs(math.sin(getTickCount()/170))*200), 1, "default-bold", "left", "top", false, false, false, true, false)
                    end
                end
            end
        end
    end
end
addEventHandler("onClientRender", root, text)

function convertTime(ms) 
    local min = math.floor ( ms/60000 ) 
    local sec = math.floor( (ms/1000)%60 ) 
    return min, sec 
end 




function isEventHandlerAdded( sEventName, pElementAttachedTo, func )
    if 
        type( sEventName ) == 'string' and 
        isElement( pElementAttachedTo ) and 
        type( func ) == 'function' 
    then
        local aAttachedFunctions = getEventHandlers( sEventName, pElementAttachedTo )
        if type( aAttachedFunctions ) == 'table' and #aAttachedFunctions > 0 then
            for i, v in ipairs( aAttachedFunctions ) do
                if v == func then
                    return true
                end
            end
        end
    end

    return false
end



function contador()
    local timer = interpolateBetween(deadTime, 0, 0, 0, 0, 0, (getTickCount()-tick)/deadTime, "Linear")
    local minutes, seconds = convertTime(timer)
    dxDrawText("remaining lifetime: "..minutes..":"..seconds, (screenW * 0.3801) + 1, (screenH * 0.9089) + 1, (screenW * 0.7059) + 1, (screenH * 1.0299) + 1, tocolor(0, 0, 0, 132), 1.00, dxfont0_fonte, "left", "top", false, false, false, false, false)
    dxDrawText("remaining lifetime: #FF0000"..minutes.."#FFFFFF:#FF0000"..seconds, screenW * 0.3801, screenH * 0.9089, screenW * 0.7059, screenH * 1.0299, tocolor(255, 255, 255, 255), 1.00, dxfont0_fonte, "left", "top", false, false, false, true, false)
end

function createShader()
    oldFilmShader, oldFilmTec = dxCreateShader("shaders/old_film.fx")
end


function updateShader()
    upDateScreenSource()

    if (oldFilmShader) then
        local flickering = math.random(100 - flickerStrength, 100)/100
        dxSetShaderValue(oldFilmShader, "ScreenSource", myScreenSource);
        dxSetShaderValue(oldFilmShader, "Flickering", flickering);
        dxDrawImage(0, 0, screenWidth, screenHeight, oldFilmShader)
    end
end



function upDateScreenSource()
    dxUpdateScreenSource(myScreenSource)
end


function render()
    if not isEventHandlerAdded("onClientRender", root, contador) then
      tick = getTickCount()
      createShader()
      addEventHandler("onClientRender", root, contador)
      addEventHandler("onClientPreRender", root, updateShader)
    end
end
addEvent("startDeadTime", true)
addEventHandler("startDeadTime", root, render)

function remove()
    if isEventHandlerAdded("onClientRender", root, contador) then
      removeEventHandler("onClientRender", root, contador)
      removeEventHandler("onClientPreRender", root, updateShader)
    end
end
addEvent("stopDeadTime", true)
addEventHandler("stopDeadTime", root, remove)

function showDeathMenu()
    if not deathMenuVisible and getElementData(localPlayer, "playerFallen") then
        showCursor(true)
        deathMenuVisible = true
        -- Removed key blocking
        if not deathMenuBrowser then
            deathMenuBrowser = guiCreateBrowser(0, 0, screenW, screenH, true, true, false)
            local theBrowser = guiGetBrowser(deathMenuBrowser)
            addEventHandler("onClientBrowserCreated", theBrowser, function()
                loadBrowserURL(theBrowser, "http://mta/local/deathmenu.html")
            end, false)
        else
            guiSetVisible(deathMenuBrowser, true)
        end
    end
end

function hideDeathMenu()
	if deathMenuVisible then
		showCursor(false)
		deathMenuVisible = false
		if deathMenuBrowser then
			destroyElement(deathMenuBrowser)
			deathMenuBrowser = nil
        end
    end
end

addEvent("showDeathMenu", true)
addEventHandler("showDeathMenu", root, showDeathMenu)
addEvent("hideDeathMenu", true)
addEventHandler("hideDeathMenu", root, hideDeathMenu)

addEvent("deathMenuCallEMS", true)
addEventHandler("deathMenuCallEMS", root, function()
    triggerServerEvent("onDeathMenuCallEMS", localPlayer)
end)

addEvent("deathMenuNewLife", true)
addEventHandler("deathMenuNewLife", root, function()
    hideDeathMenu() -- Hide menu first
    setElementHealth(localPlayer, 0) -- Then set health to 0
    -- Clear inventory and money through server event since these are server-side operations
    triggerServerEvent("onPlayerDeathAfterKnockout", localPlayer)
end)

-- Add handler for when player actually dies
addEventHandler("onClientPlayerWasted", localPlayer, function()
    if deathMenuVisible then
        hideDeathMenu()
        -- Clear inventory and money through server event since these are server-side operations
        triggerServerEvent("onPlayerDeathAfterKnockout", localPlayer)
    end
end)

-- Add handler to check player state changes
addEventHandler("onClientElementDataChange", localPlayer, function(dataName, oldValue, newValue)
    if dataName == "playerFallen" then
        if not newValue and deathMenuVisible then
            hideDeathMenu()
        end
    end
end)

function drawImmunityTimer()
    if showImmunityTimer then
        local currentTime = getTickCount()
        if currentTime < immunityEndTime then
            local timeLeft = math.ceil((immunityEndTime - currentTime) / 1000)
            local text = "Damage Immunity: " .. timeLeft .. "s"
            dxDrawText(text, (screenW * 0.3801) + 1, (screenH * 0.8589) + 1, (screenW * 0.7059) + 1, (screenH * 0.9799) + 1, tocolor(0, 0, 0, 132), 1.00, dxfont0_fonte, "left", "top", false, false, false, false, false)
            dxDrawText(text, screenW * 0.3801, screenH * 0.8589, screenW * 0.7059, screenH * 0.9799, tocolor(0, 255, 0, 255), 1.00, dxfont0_fonte, "left", "top", false, false, false, false, false)
        else
            showImmunityTimer = false
            removeEventHandler("onClientRender", root, drawImmunityTimer)
        end
    end
end

function startKnockImmunityTimer(duration)
    immunityEndTime = getTickCount() + duration
    showImmunityTimer = true
    if not isEventHandlerAdded("onClientRender", root, drawImmunityTimer) then
        addEventHandler("onClientRender", root, drawImmunityTimer)
    end
end
addEvent("startKnockImmunityTimer", true)
addEventHandler("startKnockImmunityTimer", root, startKnockImmunityTimer)

function stopKnockImmunityTimer()
	showImmunityTimer = false
	if isEventHandlerAdded("onClientRender", root, drawImmunityTimer) then
		removeEventHandler("onClientRender", root, drawImmunityTimer)
	end
end
addEvent("stopKnockImmunityTimer", true)
addEventHandler("stopKnockImmunityTimer", root, stopKnockImmunityTimer)

-- EMS revive / heal panel logic
local function ensureReviveBrowser()
	if reviveBrowser then return reviveBrowser end
	reviveBrowser = guiCreateBrowser(0, 0, screenW, screenH, true, true, false)
	local theBrowser = guiGetBrowser(reviveBrowser)
	addEventHandler("onClientBrowserCreated", theBrowser, function()
		loadBrowserURL(theBrowser, "http://mta/local/revivepanel.html")
	end, false)
	addEventHandler("onClientBrowserDocumentReady", theBrowser, function()
		reviveDocReady = true
		if pendingReviveData then
			local data = pendingReviveData
			pendingReviveData = nil
			local br = guiGetBrowser(reviveBrowser)
			local safeName = (data.name or "Unknown"):gsub("'", "\\'")
			local safeCause = (data.cause or "Unknown"):gsub("'", "\\'")
			local safeAcc = (data.accountName or "-"):gsub("'", "\\'")
			executeBrowserJavascript(br, string.format("setPatientElementId('%s');", tostring(data.id)))
			executeBrowserJavascript(br, string.format("setPatientInfo('%s', %d, %s, '%s', '%s');", safeName, math.floor(data.health or 0), tostring(data.fallen and true or false), safeCause, safeAcc))
		end
	end, false)
	guiSetVisible(reviveBrowser, false)
	return reviveBrowser
end

local function applyRevivePanelData(target, name, health, fallen, cause, accountName)
	local br = guiGetBrowser(reviveBrowser)
	local safeName = (name or "Unknown"):gsub("'", "\\'")
	local safeCause = (cause or "Unknown"):gsub("'", "\\'")
	local safeAcc = (accountName or "-"):gsub("'", "\\'")
	local id = getElementID(target) or getPlayerName(target)
	executeBrowserJavascript(br, string.format("setPatientElementId('%s');", tostring(id)))
	executeBrowserJavascript(br, string.format("setPatientInfo('%s', %d, %s, '%s', '%s');", safeName, math.floor(health or 0), tostring(fallen and true or false), safeCause, safeAcc))
end

local function showRevivePanel(target, name, health, fallen, cause, accountName)
	ensureReviveBrowser()
	currentReviveTarget = target
	guiSetVisible(reviveBrowser, true)
	revivePanelVisible = true
	showCursor(true)
	if reviveDocReady then
		applyRevivePanelData(target, name, health, fallen, cause, accountName)
	else
		pendingReviveData = {
			target = target,
			name = name,
			health = health,
			fallen = fallen,
			cause = cause,
			accountName = accountName,
			id = getElementID(target) or getPlayerName(target)
		}
	end
end

local function hideRevivePanel()
	if not reviveBrowser then return end
	guiSetVisible(reviveBrowser, false)
	revivePanelVisible = false
	showCursor(false)
	currentReviveTarget = nil
end

addEvent("emsOpenRevivePanel", true)
addEventHandler("emsOpenRevivePanel", root, function(target, name, health, fallen, cause, accountName)
	if target and isElement(target) and getElementType(target) == "player" then
		showRevivePanel(target, name, health, fallen, cause, accountName)
	end
end)

addEvent("emsRevivePanelClose", true)
addEventHandler("emsRevivePanelClose", root, function()
	hideRevivePanel()
end)

addEvent("emsClientRequestRevive", true)
addEventHandler("emsClientRequestRevive", root, function(id)
	if currentReviveTarget and isElement(currentReviveTarget) then
		triggerServerEvent("emsPerformRevive", localPlayer, currentReviveTarget)
		hideRevivePanel()
	end
end)

addEvent("emsClientRequestHeal", true)
addEventHandler("emsClientRequestHeal", root, function(id)
	if currentReviveTarget and isElement(currentReviveTarget) then
		triggerServerEvent("emsPerformHeal", localPlayer, currentReviveTarget)
		hideRevivePanel()
	end
end)

addEventHandler("onClientClick", root, function(button, state, _, _, _, _, _, clickedElement)
	if button ~= "right" or state ~= "down" then return end
	if not clickedElement or getElementType(clickedElement) ~= "player" then return end
	--if clickedElement == localPlayer then return end
	local px, py, pz = getElementPosition(localPlayer)
	local tx, ty, tz = getElementPosition(clickedElement)
	if getDistanceBetweenPoints3D(px, py, pz, tx, ty, tz) > 4 then return end
	triggerServerEvent("emsRequestRevivePanel", localPlayer, clickedElement)
end)